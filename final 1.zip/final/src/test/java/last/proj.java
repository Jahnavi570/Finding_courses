package last;
 
import java.time.Duration;
import java.util.List;
 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class proj {
    public static void main(String[] args) {
        // Setup Edge WebDriver using WebDriverManager
        //WebDriverManager.edgedriver().setup();
    	WebDriver driver = new EdgeDriver();
    	//driver.navigate().to("https://www.justdial.com/");
    	driver.get("https://www.justdial.com/");
    	driver.manage().window().maximize();
    	
    	//driver.findElement(By.xpath("//*[@id=\"loginPop\"]/div/div[2]/div/div[4]/a")).click();
    	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
    	 WebElement pop = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"loginPop\"]/div/div[2]/div/div[4]/a")));
         ((JavascriptExecutor) driver).executeScript("arguments[0].click();", pop);
         
         WebElement loc = driver.findElement(By.xpath("//input[@autocomplete='off' and @id='city-auto-sug']"));
         loc.click();
         
         WebElement pops = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"__next\"]/div/section/div[3]/span")));
         ((JavascriptExecutor) driver).executeScript("arguments[0].click();", pops);
        
         WebElement det = driver.findElement(By.xpath("//div[text()='Detect Location']"));
         det.click();
       
         WebElement search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"main-auto\"]")));
         search.sendKeys("Car Washing Services");
        
         
       
         WebElement suggestionsList = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='react-autowhatever-main-auto-suggest']/div/ul")));
      WebElement firstSuggestion = suggestionsList.findElement(By.xpath(".//li[1]"));
      firstSuggestion.click();
      
      WebElement cut=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"best_deal_div\"]/section/span")));cut.click();
    }
}