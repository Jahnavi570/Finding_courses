package last;
 
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

 
public class Finalp {
    public static void main(String[] args) {
        
    	WebDriver driver = new EdgeDriver();
    	driver.get("https://www.coursera.org/");
    	driver.manage().window().maximize();
    	
    	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
    	 WebElement search=driver.findElement(By.xpath("//*[@id=\"search-autocomplete-input\"]"));
    	 search.sendKeys("web development");

    	 search.sendKeys(Keys.RETURN);

    	 WebElement checkbox = driver.findElement(By.xpath("/html/body/div[2]/div/div/main/div[1]/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div[3]/div[1]/div[2]/div/div[1]/label/span/span/input"));
    	 if(!checkbox.isSelected()){
    		 checkbox.click();
    	 }
    	 WebElement checkbox1 = driver.findElement(By.xpath("/html/body/div[2]/div/div/main/div[1]/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div[5]/div/div/div/div[1]/label/span/span/input"));
    	 if(!checkbox1.isSelected()){
    		 checkbox1.click();
    	 }
//    	 Thread.sleep(2000);
    	 


WebElement element = driver.findElement(By.xpath("/html/body/div[2]/div/div/main/div[1]/div/div/div/div/div[2]/div/div/div[3]/div[1]/div/ul/li[1]/div/div/div/div/div/div[2]/div[1]/div[2]/a/h3"));
String elementText = element.getText();
System.out.println("Element Text: " + elementText);
driver.findElement(By.class());


    	 
    	 
    	 
    }
}